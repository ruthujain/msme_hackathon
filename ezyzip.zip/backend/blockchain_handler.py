from web3 import Web3
from config import INFURA_URL, CONTRACT_ADDRESS, ABI

# Initialize Web3 connection
w3 = Web3(Web3.HTTPProvider(INFURA_URL))

# Check if the connection is successful
if not w3.is_connected():

    raise Exception("Web3 connection failed")

# Contract initialization
contract = w3.eth.contract(address=CONTRACT_ADDRESS, abi=ABI)

# Hardcoded private key (DO NOT use this in production!)
PRIVATE_KEY = "87c455be5a1b4920be109984d0ae7853"  # Replace with your actual private key
account = w3.eth.account.privateKeyToAccount(PRIVATE_KEY)

# Fetch dynamic gas price
def get_gas_price():
    try:
        gas_price = w3.eth.gas_price  # Fetch current gas price
        return gas_price
    except Exception as e:
        print(f"Error fetching gas price: {e}")
        return w3.toWei('20', 'gwei')  # Default gas price

# Function to wait for transaction receipt
def wait_for_transaction(tx_hash, timeout=120):
    try:
        print(f"Waiting for transaction {tx_hash} to be mined...")
        receipt = w3.eth.wait_for_transaction_receipt(tx_hash, timeout=timeout)
        if receipt.status == 1:
            print(f"Transaction {tx_hash} mined successfully.")
            return receipt
        else:
            print(f"Transaction {tx_hash} failed.")
            return None
    except Exception as e:
        print(f"Error waiting for transaction: {e}")
        return None

# Function to deposit funds
def deposit_funds(amount):
    try:
        tx = contract.functions.deposit(amount).buildTransaction({
            'chainId': 1,  # Mainnet
            'gas': 2000000,
            'gasPrice': get_gas_price(),
            'nonce': w3.eth.getTransactionCount(account.address),
        })
        
        signed_tx = w3.eth.account.sign_transaction(tx, private_key=PRIVATE_KEY)
        tx_hash = w3.eth.sendRawTransaction(signed_tx.rawTransaction)
        
        # Wait for transaction to be mined
        receipt = wait_for_transaction(tx_hash)
        
        if receipt:
            return {"txHash": tx_hash.hex(), "status": "Success"}
        else:
            return {"error": "Transaction failed"}
    except Exception as e:
        print(f"Error in deposit: {e}")
        return {"error": str(e)}

# Function to release payment based on shipment ID
def release_payment(shipment_id):
    try:
        tx = contract.functions.releasePayment(shipment_id).buildTransaction({
            'chainId': 1,
            'gas': 2000000,
            'gasPrice': get_gas_price(),
            'nonce': w3.eth.getTransactionCount(account.address),
        })
        
        signed_tx = w3.eth.account.sign_transaction(tx, private_key=PRIVATE_KEY)
        tx_hash = w3.eth.sendRawTransaction(signed_tx.rawTransaction)
        
        # Wait for transaction to be mined
        receipt = wait_for_transaction(tx_hash)
        
        if receipt:
            return {"txHash": tx_hash.hex(), "status": "Success"}
        else:
            return {"error": "Transaction failed"}
    except Exception as e:
        print(f"Error in release payment: {e}")
        return {"error": str(e)}

# Example usage
if __name__ == "__main__":
    # Test deposit funds function
    deposit_response = deposit_funds(100)
    print(deposit_response)
    
    # Test release payment function
    release_response = release_payment("shipment1234")
    print(release_response)
