const Web3 = require('web3');
const { abi, evm } = require('./MSMETrade.json');  // ABI and bytecode of the compiled contract

const web3 = new Web3("https://mainnet.infura.io/v3/87c455be5a1b4920be109984d0ae7853");

const deploy = async () => {
    const accounts = await web3.eth.getAccounts();

    console.log("Deploying the contract from account:", accounts[0]);

    const result = await new web3.eth.Contract(abi)
        .deploy({ data: evm.bytecode.object })
        .send({ gas: '3000000', from: accounts[0] });

    console.log("Contract deployed to:", result.options.address);
};

deploy();
